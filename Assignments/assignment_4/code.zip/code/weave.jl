using Weave
weave("ass_4_report.jmd", out_path=:pwd, doctype="md2tex")
