using Weave
weave("ass_5_report.jmd", out_path=:pwd, doctype="md2tex")
