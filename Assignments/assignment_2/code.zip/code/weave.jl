using Weave
weave("ass_2_report.jmd", out_path=:pwd, doctype="md2tex")
